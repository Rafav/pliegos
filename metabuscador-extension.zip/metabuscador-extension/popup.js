/**
 * POPUP.JS - Metabuscador de Pliegos
 * Lógica de la interfaz de usuario
 */

// Configuración de fuentes con URLs de búsqueda
const SOURCES = {
  bne: {
    name: 'BNE Digital',
    url: 'https://bnedigital.bne.es/bd/es/results?y=s&w={query}&f=ficha&g=ws'
  },
  cordel: {
    name: 'Desenrollando el cordel',
    url: 'https://desenrollandoelcordel.unige.ch/search.html?query={query}&start=1'
  },
  mapping: {
    name: 'Mapping Pliegos',
    url: 'https://biblioteca.cchs.csic.es/MappingPliegos/resultadobusquedavanzada.php?TITULO={query}'
  },
  aracne: {
    name: 'Red-aracne',
    url: 'https://www.red-aracne.es/busqueda/resultados.htm?av=true&tituloDescricion={query}'
  },
  funjdiaz: {
    name: 'Fundación Joaquín Díaz',
    url: 'https://funjdiaz.net/pliegos-listado.php?t={query}'
  }
};

// Elementos del DOM
const queryInput = document.getElementById('query');
const searchBtn = document.getElementById('searchBtn');
const selectAllBtn = document.getElementById('selectAll');
const selectNoneBtn = document.getElementById('selectNone');
const statusDiv = document.getElementById('status');
const sourceCheckboxes = document.querySelectorAll('.source-item input[type="checkbox"]');
const quickBtns = document.querySelectorAll('.quick-btn');
const modeRadios = document.querySelectorAll('input[name="mode"]');

// ============================================
// EVENT LISTENERS
// ============================================

// Búsqueda principal
searchBtn.addEventListener('click', realizarBusqueda);
queryInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') realizarBusqueda();
});

// Seleccionar todas/ninguna fuente
selectAllBtn.addEventListener('click', () => {
  sourceCheckboxes.forEach(cb => cb.checked = true);
  guardarEstado();
});

selectNoneBtn.addEventListener('click', () => {
  sourceCheckboxes.forEach(cb => cb.checked = false);
  guardarEstado();
});

// Búsquedas rápidas
quickBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    queryInput.value = btn.dataset.query;
    realizarBusqueda();
  });
});

// Guardar selección de fuentes al cambiar
sourceCheckboxes.forEach(cb => {
  cb.addEventListener('change', guardarEstado);
});

// Guardar modo al cambiar
modeRadios.forEach(radio => {
  radio.addEventListener('change', guardarEstado);
});

// ============================================
// FUNCIONES PRINCIPALES
// ============================================

/**
 * Realizar búsqueda en las fuentes seleccionadas
 */
async function realizarBusqueda() {
  const query = queryInput.value.trim();
  
  // Validación
  if (!query) {
    mostrarEstado('⚠️ Por favor, introduce un término de búsqueda', 'error');
    queryInput.focus();
    return;
  }

  // Obtener fuentes seleccionadas
  const fuentesSeleccionadas = Array.from(sourceCheckboxes)
    .filter(cb => cb.checked)
    .map(cb => cb.value);

  if (fuentesSeleccionadas.length === 0) {
    mostrarEstado('⚠️ Selecciona al menos una fuente', 'error');
    return;
  }

  // Construir URLs
  const urls = fuentesSeleccionadas.map(sourceId => {
    const source = SOURCES[sourceId];
    if (!source) {
      console.warn(`Fuente no encontrada: ${sourceId}`);
      return null;
    }
    return source.url.replace('{query}', encodeURIComponent(query));
  }).filter(url => url !== null);

  if (urls.length === 0) {
    mostrarEstado('❌ Error al construir URLs', 'error');
    return;
  }

  // Obtener modo de apertura
  const modeChecked = document.querySelector('input[name="mode"]:checked');
  const openInNewWindow = modeChecked ? modeChecked.value === 'window' : false;

  // Mostrar estado de carga
  mostrarEstado(`⏳ Abriendo ${urls.length} pestaña${urls.length > 1 ? 's' : ''}...`, 'success');
  searchBtn.disabled = true;

  // Enviar mensaje al background script
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'openTabs',
      urls: urls,
      newWindow: openInNewWindow
    });

    if (response && response.success) {
      mostrarEstado(`✅ ${urls.length} pestaña${urls.length > 1 ? 's' : ''} abierta${urls.length > 1 ? 's' : ''}`, 'success');
      
      // Guardar última búsqueda
      guardarUltimaBusqueda(query);
      
      // Cerrar popup después de 1 segundo
      setTimeout(() => {
        window.close();
      }, 1000);
    } else {
      mostrarEstado('❌ Error al abrir pestañas', 'error');
      searchBtn.disabled = false;
    }
  } catch (error) {
    console.error('Error en búsqueda:', error);
    mostrarEstado('❌ Error: ' + error.message, 'error');
    searchBtn.disabled = false;
  }
}

/**
 * Mostrar mensaje de estado
 */
function mostrarEstado(mensaje, tipo) {
  statusDiv.textContent = mensaje;
  statusDiv.className = `status show ${tipo}`;
  
  // Auto-ocultar después de 3 segundos (solo si no es success antes de cerrar)
  if (tipo === 'error') {
    setTimeout(() => {
      statusDiv.classList.remove('show');
    }, 3000);
  }
}

/**
 * Guardar última búsqueda
 */
function guardarUltimaBusqueda(query) {
  chrome.storage.local.set({ 
    lastQuery: query,
    lastSearchTime: new Date().toISOString()
  });
}

/**
 * Guardar estado de fuentes seleccionadas y modo
 */
function guardarEstado() {
  const fuentesSeleccionadas = Array.from(sourceCheckboxes)
    .filter(cb => cb.checked)
    .map(cb => cb.value);
  
  const modoSeleccionado = document.querySelector('input[name="mode"]:checked')?.value || 'tabs';
  
  chrome.storage.local.set({
    selectedSources: fuentesSeleccionadas,
    openMode: modoSeleccionado
  });
}

/**
 * Restaurar estado guardado
 */
async function restaurarEstado() {
  try {
    const data = await chrome.storage.local.get([
      'lastQuery', 
      'selectedSources', 
      'openMode'
    ]);
    
    // Restaurar última búsqueda
    if (data.lastQuery) {
      queryInput.value = data.lastQuery;
    }
    
    // Restaurar fuentes seleccionadas
    if (data.selectedSources && Array.isArray(data.selectedSources)) {
      sourceCheckboxes.forEach(cb => {
        cb.checked = data.selectedSources.includes(cb.value);
      });
    }
    
    // Restaurar modo de apertura
    if (data.openMode) {
      const radio = document.querySelector(`input[name="mode"][value="${data.openMode}"]`);
      if (radio) radio.checked = true;
    }
    
  } catch (error) {
    console.error('Error al restaurar estado:', error);
  }
}

/**
 * Guardar búsqueda al escribir (con debounce)
 */
let saveTimeout;
queryInput.addEventListener('input', () => {
  clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    chrome.storage.local.set({ lastQuery: queryInput.value });
  }, 500);
});

// ============================================
// INICIALIZACIÓN
// ============================================

// Restaurar estado al abrir popup
document.addEventListener('DOMContentLoaded', () => {
  restaurarEstado();
  queryInput.focus();
  queryInput.select();
});

// Focus automático en el input
setTimeout(() => {
  queryInput.focus();
}, 100);

// Log para debugging
console.log('📚 Metabuscador de Pliegos - Popup cargado');
console.log(`Fuentes disponibles: ${Object.keys(SOURCES).length}`);
