# 📚 Metabuscador de Pliegos - Extensión Chrome

Extensión de Chrome para realizar búsquedas simultáneas en múltiples bases de datos de literatura popular española (pliegos sueltos y cordeles).

---

## 🎯 ¿Qué hace esta extensión?

Abre múltiples pestañas de navegador, una por cada fuente bibliográfica que selecciones, con los resultados de búsqueda de cada base de datos.

**Es como usar 5 buscadores a la vez, pero con un solo click.**

---

## 📦 Instalación

### Desde los archivos (Modo desarrollador)

1. **Descarga** esta carpeta completa
2. Abre Chrome y ve a `chrome://extensions/`
3. Activa el **"Modo de desarrollador"** (esquina superior derecha)
4. Click en **"Cargar extensión sin empaquetar"**
5. Selecciona la carpeta `metabuscador-extension`
6. ¡Listo! Verás el icono 📚 en tu barra de herramientas

### Verificar instalación

Si ves el icono del libro (📚) en la barra de herramientas de Chrome, la extensión está instalada correctamente.

---

## 🚀 Uso básico

1. **Click en el icono** 📚 de la extensión (o usa `Ctrl+Shift+P` / `Cmd+Shift+P`)
2. **Escribe** tu búsqueda (ej: "romances", "Barcelona", "monja")
3. **Selecciona** las fuentes que quieres consultar (por defecto están todas marcadas)
4. **Click en "Buscar"**
5. Se abrirán pestañas nuevas con los resultados de cada fuente

---

## 📚 Fuentes disponibles

La extensión busca en estas 5 bases de datos:

| Fuente | Descripción | Institución |
|--------|-------------|-------------|
| **📖 BNE Digital** | Biblioteca Nacional de España | BNE |
| **📜 Desenrollando el cordel** | Literatura de cordel | Universidad de Ginebra |
| **🗺️ Mapping Pliegos** | Cartografía de pliegos | CSIC |
| **🕸️ Red-aracne** | Metabuscador BIDISO | Universidad de La Rioja |
| **🎵 Fundación Joaquín Díaz** | Folklore y cultura popular | Fundación privada |

---

## ⚙️ Opciones

### Modo de apertura

- **Pestañas nuevas**: Abre cada resultado en una pestaña separada en la ventana actual
- **Ventana nueva**: Abre todas las pestañas en una ventana nueva

### Búsquedas rápidas

Click en cualquiera de estos botones para buscar términos comunes:
- `romances`
- `cautivos`
- `Barcelona`
- `monja`
- `Diego Corrientes`
- `muerte`

---

## ⌨️ Atajos de teclado

- **`Ctrl+Shift+P`** (Windows/Linux) o **`Cmd+Shift+P`** (Mac): Abrir la extensión
- **`Enter`**: Realizar búsqueda desde el campo de texto

---

## 🎓 Características educativas

Esta extensión fue desarrollada como **ejercicio educativo para ASIR** (Administración de Sistemas Informáticos en Red) y demuestra:

### Competencias técnicas
- ✅ **Chrome Extension API** (Manifest V3)
- ✅ **Service Workers** (background scripts)
- ✅ **Chrome Storage API** (persistencia de datos)
- ✅ **Tab Management** (gestión de pestañas)
- ✅ **Message Passing** (comunicación entre scripts)

### Ventajas sobre soluciones web
- ✅ **Sin problemas de CORS**: Las extensiones tienen permisos especiales
- ✅ **Sin servidor necesario**: Todo funciona en el navegador
- ✅ **Datos siempre actualizados**: Consulta directa a las fuentes
- ✅ **Experiencia nativa**: Usa las pestañas del navegador

---

## 🔧 Estructura del proyecto

```
metabuscador-extension/
├── manifest.json       # Configuración de la extensión
├── popup.html         # Interfaz de usuario
├── popup.css          # Estilos
├── popup.js           # Lógica del popup
├── background.js      # Service worker (gestión de pestañas)
├── icons/             # Iconos de la extensión
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md          # Este archivo
```

---

## 🛠️ Desarrollo y personalización

### Añadir una nueva fuente

Edita `popup.js` y añade la fuente al objeto `SOURCES`:

```javascript
const SOURCES = {
  // ... fuentes existentes
  miNuevaFuente: {
    name: 'Mi Nueva Fuente',
    url: 'https://ejemplo.com/buscar?q={query}'
  }
};
```

Luego añade el checkbox en `popup.html`:

```html
<label class="source-item">
  <input type="checkbox" value="miNuevaFuente" checked>
  <span class="source-name">🆕 Mi Nueva Fuente</span>
</label>
```

### Modificar estilos

Todos los estilos están en `popup.css`. El diseño usa:
- Variables CSS para colores consistentes
- Flexbox para layouts responsivos
- Transiciones suaves para interacciones

### Debug

1. Abre `chrome://extensions/`
2. Busca "Metabuscador de Pliegos"
3. Click en "Inspeccionar vista del service worker" para ver logs del background
4. Click derecho en el icono → "Inspeccionar popup" para debuggear la interfaz

---

## 🐛 Problemas comunes

### La extensión no aparece

- ✅ Verifica que el "Modo de desarrollador" esté activado
- ✅ Recarga la extensión desde `chrome://extensions/`
- ✅ Comprueba que todos los archivos estén presentes

### No se abren las pestañas

- ✅ Revisa la consola del service worker (puede haber errores)
- ✅ Verifica que Chrome tenga permisos para abrir pestañas
- ✅ Comprueba tu conexión a internet

### Las URLs no funcionan

- ✅ Algunas fuentes pueden cambiar sus URLs de búsqueda
- ✅ Edita `popup.js` para actualizar las URLs si es necesario

---

## 🔮 Mejoras futuras posibles

Ideas para extender la extensión:

- [ ] **Scraping de resultados**: Extraer y mostrar resumen unificado
- [ ] **Tab Groups**: Agrupar automáticamente las pestañas por búsqueda
- [ ] **Historial**: Guardar y mostrar búsquedas anteriores
- [ ] **Exportar**: Guardar todas las URLs en un archivo
- [ ] **Notificaciones**: Avisar cuando terminen de cargar las páginas
- [ ] **Estadísticas**: Mostrar uso de la extensión
- [ ] **Filtros**: Filtrar resultados por fecha, tipo, etc.
- [ ] **Marcadores**: Guardar resultados interesantes

---

## 📄 Licencia

Este proyecto es educativo y de código abierto. Libre para uso, modificación y distribución con fines educativos.

---

## 🙏 Créditos

### Fuentes de datos

Agradecimiento a los proyectos que digitalizan y preservan el patrimonio bibliográfico español:

- [BIDISO](https://www.bidiso.es/) - Universidad de La Rioja
- [Desenrollando el cordel](https://desenrollandoelcordel.unige.ch/) - Universidad de Ginebra
- [Mapping Pliegos](http://biblioteca.cchs.csic.es/MappingPliegos/) - CSIC
- [Fundación Joaquín Díaz](https://funjdiaz.net/)
- [Biblioteca Nacional de España](http://catalogo.bne.es/)

### Desarrollo

- **Proyecto**: Metabuscador de Pliegos
- **Contexto**: ASIR - Formación Profesional
- **Año**: 2025
- **Propósito**: Ejercicio educativo de desarrollo web y extensiones

---

## 📞 Soporte

Para problemas técnicos:
1. Revisa la sección **"Problemas comunes"** arriba
2. Inspecciona la consola del navegador (F12)
3. Verifica los logs del service worker

---

## ⭐ Changelog

### v1.0.0 (Enero 2025)
- ✨ Lanzamiento inicial
- ✅ 5 fuentes integradas
- ✅ Búsquedas rápidas
- ✅ Modo pestañas/ventana nueva
- ✅ Persistencia de preferencias
- ✅ Atajos de teclado
- ✅ URLs verificadas y actualizadas

---

**¡Feliz búsqueda!** 📚
