/**
 * BACKGROUND.JS - Metabuscador de Pliegos
 * Service Worker para gestión de pestañas
 */

// ============================================
// MESSAGE LISTENER
// ============================================

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Mensaje recibido:', request.action);
  
  if (request.action === 'openTabs') {
    abrirMultiplesTabs(request.urls, request.newWindow)
      .then(() => {
        console.log('✅ Pestañas abiertas correctamente');
        sendResponse({ success: true });
      })
      .catch((error) => {
        console.error('❌ Error al abrir tabs:', error);
        sendResponse({ success: false, error: error.message });
      });
    
    // Importante: return true para mantener el canal de mensajes abierto
    return true;
  }
  
  if (request.action === 'resultadosExtraidos') {
    // Manejar resultados scrapeados (futuro)
    console.log('📊 Resultados extraídos:', request);
    sendResponse({ success: true });
    return true;
  }
});

// ============================================
// FUNCIONES PRINCIPALES
// ============================================

/**
 * Abrir múltiples pestañas
 * @param {Array<string>} urls - Array de URLs a abrir
 * @param {boolean} newWindow - Si debe abrir en ventana nueva
 */
async function abrirMultiplesTabs(urls, newWindow = false) {
  if (!urls || urls.length === 0) {
    throw new Error('No hay URLs para abrir');
  }

  console.log(`🚀 Abriendo ${urls.length} pestañas (newWindow: ${newWindow})`);

  try {
    if (newWindow) {
      // Opción 1: Abrir en ventana nueva
      await abrirEnVentanaNueva(urls);
    } else {
      // Opción 2: Abrir en ventana actual
      await abrirEnVentanaActual(urls);
    }
  } catch (error) {
    console.error('Error en abrirMultiplesTabs:', error);
    throw error;
  }
}

/**
 * Abrir pestañas en ventana nueva
 */
async function abrirEnVentanaNueva(urls) {
  // Crear ventana con la primera URL
  const nuevaVentana = await chrome.windows.create({
    url: urls[0],
    focused: true,
    type: 'normal'
  });

  console.log(`📱 Ventana creada: ${nuevaVentana.id}`);

  // Añadir las demás URLs como pestañas en esa ventana
  for (let i = 1; i < urls.length; i++) {
    await chrome.tabs.create({
      url: urls[i],
      windowId: nuevaVentana.id,
      active: false
    });
    
    // Pequeño delay para evitar sobrecarga
    await delay(100);
  }

  console.log(`✅ ${urls.length} pestañas creadas en nueva ventana`);
}

/**
 * Abrir pestañas en ventana actual
 */
async function abrirEnVentanaActual(urls) {
  const ventanaActual = await chrome.windows.getCurrent();
  
  console.log(`📱 Ventana actual: ${ventanaActual.id}`);

  let primeraPestañaId = null;

  // Crear todas las pestañas
  for (let i = 0; i < urls.length; i++) {
    const nuevaPestaña = await chrome.tabs.create({
      url: urls[i],
      windowId: ventanaActual.id,
      active: i === 0 // Solo la primera está activa
    });

    if (i === 0) {
      primeraPestañaId = nuevaPestaña.id;
    }

    // Pequeño delay entre pestañas
    await delay(100);
  }

  // Activar la primera pestaña creada
  if (primeraPestañaId) {
    await chrome.tabs.update(primeraPestañaId, { active: true });
  }

  console.log(`✅ ${urls.length} pestañas creadas en ventana actual`);
}

/**
 * Agrupar pestañas (Chrome 89+)
 * Agrupa todas las pestañas del metabuscador
 */
async function agruparPestañas(tabIds) {
  try {
    // Verificar si Tab Groups API está disponible
    if (chrome.tabGroups) {
      const groupId = await chrome.tabs.group({ tabIds: tabIds });
      
      await chrome.tabGroups.update(groupId, {
        title: '📚 Pliegos',
        color: 'purple',
        collapsed: false
      });
      
      console.log(`📁 Pestañas agrupadas: ${tabIds.length}`);
    }
  } catch (error) {
    console.warn('No se pudieron agrupar las pestañas:', error);
  }
}

// ============================================
// UTILIDADES
// ============================================

/**
 * Delay helper
 */
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================
// INSTALACIÓN Y ACTUALIZACIÓN
// ============================================

// Al instalar la extensión
chrome.runtime.onInstalled.addListener((details) => {
  console.log('📦 Extensión instalada/actualizada:', details.reason);
  
  if (details.reason === 'install') {
    // Primera instalación
    console.log('🎉 ¡Bienvenido al Metabuscador de Pliegos!');
    
    // Abrir página de bienvenida (opcional)
    // chrome.tabs.create({ url: 'welcome.html' });
    
    // Configuración inicial
    chrome.storage.local.set({
      selectedSources: ['bne', 'cordel', 'mapping', 'aracne'],
      openMode: 'tabs',
      installDate: new Date().toISOString()
    });
  } else if (details.reason === 'update') {
    console.log(`📱 Actualizado a versión ${chrome.runtime.getManifest().version}`);
  }
});

// Al iniciar Chrome
chrome.runtime.onStartup.addListener(() => {
  console.log('🚀 Chrome iniciado - Service Worker activo');
});

// ============================================
// ATAJOS DE TECLADO (opcional)
// ============================================

chrome.commands.onCommand.addListener((command) => {
  console.log(`⌨️ Comando recibido: ${command}`);
  
  if (command === '_execute_action') {
    // Abrir popup (manejado automáticamente por Chrome)
    console.log('Abriendo popup via atajo');
  }
});

// ============================================
// ESTADÍSTICAS (opcional)
// ============================================

/**
 * Guardar estadísticas de uso
 */
async function registrarBusqueda(numTabs) {
  try {
    const data = await chrome.storage.local.get(['totalSearches', 'totalTabs']);
    
    await chrome.storage.local.set({
      totalSearches: (data.totalSearches || 0) + 1,
      totalTabs: (data.totalTabs || 0) + numTabs,
      lastSearch: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error al registrar estadísticas:', error);
  }
}

// ============================================
// LOG INICIAL
// ============================================

console.log('📚 Metabuscador de Pliegos - Service Worker iniciado');
console.log(`Versión: ${chrome.runtime.getManifest().version}`);
console.log(`Manifest: V${chrome.runtime.getManifest().manifest_version}`);
